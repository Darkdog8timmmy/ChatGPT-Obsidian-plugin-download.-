---
name: people-context
description: Use when the user wants to understand, categorize, or maintain context about people in their life.
---

# People context workflow

1. Search `Al's brain/People` for the person's existing note.
2. Read the note before asking questions, so questions fill gaps rather than repeat known context.
3. Ask only the highest-value questions needed to classify the relationship, current context, preferences, boundaries, and follow-ups.
4. Keep sensitive information minimal and factual. Do not infer private traits.
5. Create or update a Markdown note at `Al's brain/People/<Name>.md` with headings such as `Relationship`, `How we know each other`, `What matters to them`, `Current context`, `Follow-ups`, and `Last reviewed`.
6. Log the note operation with `log_activity`.
