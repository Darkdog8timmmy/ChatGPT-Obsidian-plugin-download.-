---
name: brain-maintenance
description: Use when ChatGPT should create, update, organize, or log durable second-brain context in Obsidian.
---

# Second-brain maintenance

- Store durable personal context under `Al's brain`.
- Store people notes under `Al's brain/People`.
- Prefer one topic per note and stable Markdown headings.
- Before overwriting an existing note, read it and preserve information that is not contradicted.
- Use `create_note`, `update_note`, `append_note`, and `move_note` for file operations.
- Every AI-created or AI-edited note must be recorded with `log_activity`, including the action, path, and short reason.
- Never delete notes as part of ordinary maintenance. Move to a clearly named archive only when explicitly requested.
- Ask focused questions before creating a people note when identity, relationship, or sensitive details are unclear.
