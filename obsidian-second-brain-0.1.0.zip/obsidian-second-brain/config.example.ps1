$env:OBSIDIAN_VAULT_PATH = 'C:\Path\To\Your\Vault'
# Optional overrides:
# $env:OBSIDIAN_BRAIN_FOLDER = "Al's brain"
# $env:OBSIDIAN_AI_LOG_FOLDER = 'AI skills/ChatGPT Logs'
