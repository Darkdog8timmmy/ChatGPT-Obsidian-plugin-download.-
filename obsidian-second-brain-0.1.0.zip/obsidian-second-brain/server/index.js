#!/usr/bin/env node
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const readline = require('readline');

const configuredVault = process.env.OBSIDIAN_VAULT_PATH || '';
const vault = path.resolve(configuredVault || process.cwd());
const brainFolder = process.env.OBSIDIAN_BRAIN_FOLDER || "Al's brain";
const logFolder = process.env.OBSIDIAN_AI_LOG_FOLDER || 'AI skills/ChatGPT Logs';

function error(message, code = 'INVALID_REQUEST') { const e = new Error(message); e.code = code; return e; }
function rel(input) {
  if (typeof input !== 'string' || !input.trim()) throw error('A non-empty vault-relative path is required.');
  const normalized = input.replace(/\\/g, '/').replace(/^\/+/, '');
  if (normalized.split('/').includes('..') || path.isAbsolute(input)) throw error('Path traversal and absolute paths are not allowed.');
  const abs = path.resolve(vault, normalized);
  if (abs !== vault && !abs.startsWith(vault + path.sep)) throw error('Path must remain inside the configured vault.');
  return { relative: normalized, absolute: abs };
}
async function ensureVault() {
  if (!configuredVault) throw error('OBSIDIAN_VAULT_PATH is not configured.', 'NOT_CONFIGURED');
  const st = await fsp.stat(vault).catch(() => null);
  if (!st || !st.isDirectory()) throw error('Configured OBSIDIAN_VAULT_PATH is not a directory.', 'NOT_CONFIGURED');
}
async function ensureParent(abs) { await fsp.mkdir(path.dirname(abs), { recursive: true }); }
function json(value) { return JSON.stringify(value, null, 2); }
async function listFiles(dir, out = []) {
  for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.') || entry.name === '.obsidian') continue;
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) await listFiles(abs, out);
    else if (/\.(md|mdx|txt|canvas|json)$/i.test(entry.name)) out.push(path.relative(vault, abs).replace(/\\/g, '/'));
  }
  return out;
}
function excerpt(text, query, max = 600) {
  const clean = text.replace(/\r/g, '');
  if (!query) return clean.slice(0, max);
  const i = clean.toLowerCase().indexOf(query.toLowerCase());
  return clean.slice(Math.max(0, i < 0 ? 0 : i - 180), Math.max(0, i < 0 ? 0 : i - 180) + max);
}
async function tool(name, args = {}) {
  await ensureVault();
  if (name === 'list_notes') {
    const files = await listFiles(vault); return { files, count: files.length };
  }
  if (name === 'search_notes' || name === 'get_brain_context') {
    const query = String(args.query || '').trim(); if (!query) throw error('query is required.');
    const limit = Math.min(Math.max(Number(args.limit) || 10, 1), 50); const files = await listFiles(vault); const results = [];
    const preferred = name === 'get_brain_context' ? files.sort((a,b) => (b.startsWith(brainFolder) - a.startsWith(brainFolder))) : files;
    for (const file of preferred) { if (results.length >= limit) break; const text = await fsp.readFile(path.join(vault, file), 'utf8').catch(() => ''); if (text.toLowerCase().includes(query.toLowerCase()) || file.toLowerCase().includes(query.toLowerCase())) results.push({ path: file, excerpt: excerpt(text, query) }); }
    return { query, results };
  }
  if (name === 'read_note') { const p = rel(args.path); const text = await fsp.readFile(p.absolute, 'utf8').catch(() => { throw error('Note not found.', 'NOT_FOUND'); }); return { path: p.relative, content: text }; }
  if (name === 'create_note') { const p = rel(args.path); if (await fsp.access(p.absolute).then(() => true).catch(() => false)) throw error('Note already exists.', 'ALREADY_EXISTS'); await ensureParent(p.absolute); const content = String(args.content || ''); await fsp.writeFile(p.absolute, content, 'utf8'); return { created: true, path: p.relative }; }
  if (name === 'update_note') { const p = rel(args.path); await fsp.access(p.absolute).catch(() => { throw error('Note not found.', 'NOT_FOUND'); }); await fsp.writeFile(p.absolute, String(args.content || ''), 'utf8'); return { updated: true, path: p.relative }; }
  if (name === 'append_note') { const p = rel(args.path); await fsp.access(p.absolute).catch(() => { throw error('Note not found.', 'NOT_FOUND'); }); await fsp.appendFile(p.absolute, String(args.content || ''), 'utf8'); return { appended: true, path: p.relative }; }
  if (name === 'move_note') { const from = rel(args.from); const to = rel(args.to); await ensureParent(to.absolute); await fsp.rename(from.absolute, to.absolute); return { moved: true, from: from.relative, to: to.relative }; }
  if (name === 'log_activity') {
    const stamp = new Date().toISOString(); const logPath = path.posix.join(logFolder.replace(/\\/g, '/'), `${stamp.slice(0, 10)}.md`); const p = rel(logPath); await ensureParent(p.absolute);
    const entry = `\n## ${stamp}\n- Action: ${String(args.action || 'unspecified')}\n- Note: ${String(args.path || 'n/a')}\n- Reason: ${String(args.reason || 'n/a')}\n`;
    await fsp.appendFile(p.absolute, entry, 'utf8'); return { logged: true, path: p.relative, timestamp: stamp };
  }
  throw error(`Unknown tool: ${name}`);
}

const tools = [
  { name: 'list_notes', description: 'List supported note files in the vault.', inputSchema: { type: 'object', properties: {} } },
  { name: 'search_notes', description: 'Search note paths and contents for a query.', inputSchema: { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number' } }, required: ['query'] } },
  { name: 'get_brain_context', description: 'Search for context, prioritizing Al\'s brain.', inputSchema: { type: 'object', properties: { query: { type: 'string' }, limit: { type: 'number' } }, required: ['query'] } },
  { name: 'read_note', description: 'Read one vault-relative note.', inputSchema: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'] } },
  { name: 'create_note', description: 'Create a new note inside the vault.', inputSchema: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } },
  { name: 'update_note', description: 'Replace the content of an existing note.', inputSchema: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } },
  { name: 'append_note', description: 'Append content to an existing note.', inputSchema: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'] } },
  { name: 'move_note', description: 'Move a note within the vault.', inputSchema: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' } }, required: ['from', 'to'] } },
  { name: 'log_activity', description: 'Log an AI-created or AI-edited note in the configured AI skills log folder.', inputSchema: { type: 'object', properties: { action: { type: 'string' }, path: { type: 'string' }, reason: { type: 'string' } }, required: ['action', 'path', 'reason'] } }
];

function reply(id, result, isError = false) { process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id, result: isError ? { isError: true, content: [{ type: 'text', text: result }] } : result }) + '\n'); }
const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', async line => { if (!line.trim()) return; let req; try { req = JSON.parse(line); } catch { return; }
  try {
    if (req.method === 'initialize') reply(req.id, { protocolVersion: '2024-11-05', capabilities: { tools: {} }, serverInfo: { name: 'obsidian-second-brain', version: '0.1.0' } });
    else if (req.method === 'notifications/initialized') return;
    else if (req.method === 'tools/list') reply(req.id, { tools });
    else if (req.method === 'tools/call') reply(req.id, { content: [{ type: 'text', text: json(await tool(req.params.name, req.params.arguments || {})) }] });
    else if (req.id !== undefined) reply(req.id, { code: 'METHOD_NOT_FOUND', message: req.method }, true);
  } catch (e) { if (req.id !== undefined) reply(req.id, `${e.code || 'ERROR'}: ${e.message}`, true); }
});
