# Obsidian Second Brain

This local plugin gives a supported MCP host scoped access to one Obsidian vault. It is designed for conversational workflows: retrieve context, search notes, create or update notes, organize files, maintain people notes, and log AI activity.

## Setup

Set `OBSIDIAN_VAULT_PATH` to the absolute path of the vault before launching the host. Optional environment variables:

- `OBSIDIAN_BRAIN_FOLDER` — defaults to `Al's brain`.
- `OBSIDIAN_AI_LOG_FOLDER` — defaults to `AI skills/ChatGPT Logs`.

The server rejects paths outside the configured vault and refuses symlinks that resolve outside it. Markdown is the intended note format, but existing text files can be read and moved.

## Included workflows

- `vault-context`: retrieve relevant notes before answering or acting.
- `brain-maintenance`: create durable context notes and keep the activity log accurate.
- `people-context`: ask questions about a person, then create or update a structured note under `Al's brain/People`.

## Mobile and hosted Work

This package uses a local stdio server, so it is suitable for desktop/local hosts with access to the vault. A phone or hosted Work session cannot directly reach a computer's filesystem. To support those surfaces, deploy the same tool contract behind a secured remote MCP endpoint or use an Obsidian REST/sync bridge; do not expose a vault directory or unauthenticated HTTP endpoint.
